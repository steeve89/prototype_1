
<table border="0" cellpadding="0" align="center" cellspacing="0" width="100%" >
    <tr>
        <td align="center" style="padding: 15px;">

            <div style="line-height: normal; font-size: 25px; font-family: Helvetica; color: #333333; text-align: center; border: 0; width: 100%!important; display: block; background-color: transparent" class="tnpc-row-edit" data-type="title">An Awesome Title</div>

        </td>
    </tr>
</table>
