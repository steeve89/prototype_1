<?php
if (!defined('ABSPATH')) exit;
?>
<!-- Footer -->
<div style="text-align: center; font-weight: bold; margin: 40px 0 10px;"><?php echo $theme_options['main_footer_title'] ?></div>
<div style="text-align: center; margin: 10px 0 20px;"><?php echo $theme_options['main_footer_contact'] ?></div>

<?php include WP_PLUGIN_DIR . '/newsletter/emails/themes/default/social_main.php'; ?>

<div style="text-align: center; color: #888; margin-top: 20px;"><?php echo $theme_options['main_footer_legal'] ?></div>
<div style="text-align: center; color: #888">To change your subscription, <a target="_blank"  href="{profile_url}">click here</a>.</div>